package com.fx.pojo;

public class User1 {

	private int uid;
	private String name;
	private String password;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User1(int uid, String name, String password) {
		super();
		this.uid = uid;
		this.name = name;
		this.password = password;
	}
	public User1() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User1 [uid=" + uid + ", name=" + name + ", password=" + password + "]";
	}
	
	
}
