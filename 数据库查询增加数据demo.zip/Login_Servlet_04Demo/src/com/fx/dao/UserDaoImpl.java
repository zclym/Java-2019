package com.fx.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.fx.pojo.User1;

public class UserDaoImpl implements UserDao {

	Connection conn = null;
	PreparedStatement Statement = null;
	ResultSet set = null;
	User1 u = null;

	@Override
	public User1 checkLoginDao(String name, String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gdsdemo", "root", "root");
		String sql = "select * from user where name=? and password=?";
		Statement = conn.prepareStatement(sql);
		Statement.setString(1, name);
		Statement.setString(2, password);
		set = Statement.executeQuery();
		while (set.next()) {
			u = new User1();
			u.setUid(set.getInt("uid"));
			u.setName(set.getString("name"));
			u.setPassword(set.getString("password"));
		}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				set.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return u;
	}

}
