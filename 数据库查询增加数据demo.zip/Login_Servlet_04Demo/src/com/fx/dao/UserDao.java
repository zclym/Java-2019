package com.fx.dao;

import com.fx.pojo.User1;

public interface UserDao {
  User1 checkLoginDao(String name,String password);
}
