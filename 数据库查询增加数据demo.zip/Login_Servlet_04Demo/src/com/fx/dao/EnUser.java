package com.fx.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fx.pojo.User1;

public class EnUser implements UserDao {

	Connection conn = null;
	PreparedStatement Statement = null;
	ResultSet set = null;
	User1 u = null;

	@Override
	public User1 checkLoginDao(String name, String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gdsdemo", "root", "root");
		String sql = "insert into user(name,password) values(?,?)";
		Statement = conn.prepareStatement(sql);
		Statement.setString(1, name);
		Statement.setString(2, password);
		Statement.execute();
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
						try {
				Statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return u;
	}
	}

}
