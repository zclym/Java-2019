package com.fx.service;

import com.fx.pojo.User1;

public interface UserService {
  User1 checkLoginService(String name,String password);
}
