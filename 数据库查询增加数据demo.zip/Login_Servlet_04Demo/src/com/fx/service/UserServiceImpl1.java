package com.fx.service;

import com.fx.dao.EnUser;
import com.fx.dao.UserDao;
import com.fx.pojo.User1;

public class UserServiceImpl1 implements UserService {

	UserDao ud1 = new EnUser();

	@Override
	public User1 checkLoginService(String name, String password) {
		// TODO Auto-generated method stub
		return ud1.checkLoginDao(name, password);
	}

}
