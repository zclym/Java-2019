package com.fx.service;

import com.fx.dao.UserDao;
import com.fx.dao.UserDaoImpl;
import com.fx.pojo.User1;

public class UserServiceImpl implements UserService {
   UserDao ud = new UserDaoImpl();
	
	@Override
	public User1 checkLoginService(String name, String password) {
		
		return ud.checkLoginDao(name, password);
	}

}
