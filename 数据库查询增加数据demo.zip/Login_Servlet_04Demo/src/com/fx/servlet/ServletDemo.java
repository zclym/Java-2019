package com.fx.servlet;

import java.io.IOException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.User;

import com.fx.pojo.User1;
import com.fx.service.UserService;
import com.fx.service.UserServiceImpl;

/**
 * Servlet implementation class ServletDemo
 */
@WebServlet("/demo")
public class ServletDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String names = request.getParameter("uname");
		String password = request.getParameter("pwd");
     UserService us  = new UserServiceImpl();
     User1 use = us.checkLoginService(names, password);
	System.out.println(use);
	if (use!=null) {
//		response.getWriter().write("��¼�ɹ�");
		request.getRequestDispatcher("win.jsp").forward(request, response);
		
	}else {
//		response.getWriter().write("��¼ʧ��");
		request.getRequestDispatcher("enter1.jsp").forward(request, response);
	}
	
	}

}
