package com.fx.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fx.pojo.User1;
import com.fx.service.UserService;
import com.fx.service.UserServiceImpl;
import com.fx.service.UserServiceImpl1;

/**
 * Servlet implementation class ServletDemo1
 */
@WebServlet("/demo1")
public class ServletDemo1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String names = request.getParameter("names");
		String password = request.getParameter("pwds");
		System.out.println("��ȡ����"+names+":"+password);
     UserServiceImpl us  = new UserServiceImpl();
     User1 use = us.checkLoginService(names, password);
	System.out.println(use);
	if (use==null) {
		UserServiceImpl1 uu = new UserServiceImpl1();
		User1 uses = uu.checkLoginService(names, password);
		request.getRequestDispatcher("enter1.jsp").forward(request, response);
		response.getWriter().write("ע��ɹ�");
		
	}else {
		request.getRequestDispatcher("enroll.jsp").forward(request, response);
		response.getWriter().write("ע��ʧ��");
		
	}
	}

}
